package com.shopping;

public interface CustomerType {
	double calculateFinalAmount(double purchasedAmount);
}
