package com.shopping;

public class RegularType implements CustomerType{

	@Override
	public double calculateFinalAmount(double purchasedAmount) {
		
		double amountToReturn = 0.0d;
		if(purchasedAmount <= 5000) {
			amountToReturn = purchasedAmount;
		}else if(purchasedAmount <= 10000) {	
			amountToReturn = purchasedAmount - ((purchasedAmount-5000)*10)/100;
		}else if(purchasedAmount > 10000) {
			amountToReturn = purchasedAmount - (500 + ((purchasedAmount-10000)*20)/100);
		}
		return amountToReturn;
	}
}