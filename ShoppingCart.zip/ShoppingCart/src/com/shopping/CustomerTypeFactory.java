package com.shopping;

public class CustomerTypeFactory {
	public static CustomerType getCustomerType(String customerType) {
		if(customerType.equalsIgnoreCase("Regular")) {
			return new RegularType();
		}else if(customerType.equalsIgnoreCase("Premium")) {
			return new PremiumType();
		}
		return null;
	}
}
