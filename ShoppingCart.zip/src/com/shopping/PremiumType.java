package com.shopping;

public class PremiumType implements CustomerType{

	@Override
	public double calculateFinalAmount(double purchasedAmount) {
		double amountToReturn = 0.0d;
		if(purchasedAmount <= 4000) {
			amountToReturn = purchasedAmount - (purchasedAmount*10)/100;
		}else if(purchasedAmount <= 8000) {	
			amountToReturn = purchasedAmount - (400 + ((purchasedAmount-4000)*15)/100);
		}else if(purchasedAmount <= 12000) {
			amountToReturn = purchasedAmount - (1000 + ((purchasedAmount-8000)*20)/100);
		}else if(purchasedAmount > 12000) {
			amountToReturn = purchasedAmount - (1800 + ((purchasedAmount-12000)*30)/100);
		}
		return amountToReturn;
	}

}
